import { lazy, Suspense } from 'react'
import Navbar from './components/Navbar'
import Chatbot from './components/Chatbot'
import Header from './components/Header'

const Skills = lazy(() => import('./components/Skills'))
const Experience = lazy(() => import('./components/Experience'))
const Projects = lazy(() => import('./components/Projects'))
const Education = lazy(() => import('./components/Education'))
const Honors = lazy(() => import('./components/Honors'))
const Contact = lazy(() => import('./components/Contact'))

function Footer() {
  return (
    <footer className="text-center py-8 text-sm text-slate-500 border-t border-slate-200 bg-white">
      <span className="inline-block animate-pulse mr-1">✦</span>
      Built with React — data from <code className="bg-slate-100 px-1.5 py-0.5 rounded text-xs font-mono">portfolio.json</code>
    </footer>
  )
}

function SectionSkeleton() {
  return (
    <section className="min-h-screen flex items-center justify-center px-4 bg-white">
      <div className="w-full max-w-4xl animate-pulse space-y-6">
        <div className="h-6 bg-slate-200 rounded-full w-48 mx-auto" />
        <div className="h-4 bg-slate-100 rounded w-64 mx-auto" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8">
          <div className="h-32 bg-slate-100 rounded-xl" />
          <div className="h-32 bg-slate-100 rounded-xl" />
        </div>
      </div>
    </section>
  )
}

export default function App() {
  return (
    <div className="text-slate-900 font-sans">
      <Navbar />
      <Header />
      <Suspense fallback={<SectionSkeleton />}><Skills /></Suspense>
      <Suspense fallback={<SectionSkeleton />}><Experience /></Suspense>
      <Suspense fallback={<SectionSkeleton />}><Projects /></Suspense>
      <Suspense fallback={<SectionSkeleton />}><Education /></Suspense>
      <Suspense fallback={<SectionSkeleton />}><Honors /></Suspense>
      <Suspense fallback={<SectionSkeleton />}><Contact /></Suspense>
      <Footer />
      <Chatbot />
    </div>
  )
}
