import { memo } from 'react'
import { useInView } from '../hooks/useInView'
import data from '../data/portfolio.json'

function Skills() {
  const { skills } = data
  const [ref, inView] = useInView()

  const entries = Object.entries(skills)

  return (
    <section
      id="skills"
      ref={ref}
      className="relative min-h-screen flex items-center px-4 py-16 bg-slate-900"
    >
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,_var(--tw-gradient-stops))] from-blue-900/20 via-transparent to-transparent" />
      <div className="relative w-full max-w-5xl mx-auto">
        <h2 className={`text-3xl md:text-4xl font-bold text-white text-center mb-4 transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}>
          Technical Skills
        </h2>
        <p className={`text-slate-400 text-center mb-12 max-w-xl mx-auto transition-all duration-700 delay-100 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}>
          Technologies and tools I work with daily
        </p>

        <div className={`grid grid-cols-1 md:grid-cols-2 gap-4 animate-stagger ${inView ? 'visible' : ''}`}>
          {entries.map(([category, items]) => (
            <div
              key={category}
              className="group bg-white/5 backdrop-blur-sm rounded-2xl p-5 border border-white/10 hover:bg-white/10 hover:border-blue-500/30 transition-all duration-300"
            >
              <div className="flex items-center gap-2 mb-3">
                <div className="w-1 h-5 rounded-full bg-blue-500 group-hover:h-6 transition-all" />
                <h3 className="text-xs font-semibold text-blue-300 uppercase tracking-widest">{category}</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {items.map((skill) => (
                  <span
                    key={skill}
                    className="px-3 py-1 bg-white/5 border border-white/5 rounded-full text-sm text-slate-300 hover:bg-blue-600/20 hover:text-blue-200 hover:border-blue-500/30 transition-all duration-200"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default memo(Skills)
