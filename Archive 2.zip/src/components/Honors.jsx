import { memo } from 'react'
import { useInView } from '../hooks/useInView'
import data from '../data/portfolio.json'

function Honors() {
  const { honors, languages } = data
  const [ref, inView] = useInView()

  return (
    <section
      id="honors"
      ref={ref}
      className="relative min-h-screen flex items-center px-4 py-16 bg-slate-50"
    >
      <div className="w-full max-w-4xl mx-auto">
        <h2 className={`text-3xl md:text-4xl font-bold text-slate-900 text-center mb-4 transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}>
          Honors & Languages
        </h2>
        <p className={`text-slate-500 text-center mb-12 transition-all duration-700 delay-100 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}>
          Recognition and communication
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className={`bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-all duration-500 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <h3 className="text-sm font-semibold text-blue-600 uppercase tracking-widest mb-4 flex items-center gap-2">
              <span className="text-amber-400">★</span>
              Honors & Achievements
            </h3>
            <ul className="space-y-3">
              {honors.map((h, i) => (
                <li key={i} className="flex gap-2 text-sm text-slate-700">
                  <span className="text-amber-400 mt-0.5 shrink-0">✦</span>
                  <span>{h}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className={`bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-all duration-500 delay-150 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <h3 className="text-sm font-semibold text-blue-600 uppercase tracking-widest mb-4 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
              Languages
            </h3>
            <div className="space-y-4">
              {Object.entries(languages).map(([lang, level]) => (
                <div key={lang}>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-sm font-medium text-slate-800">{lang}</span>
                    <span className="text-xs text-slate-500">{level}</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-blue-500 to-blue-400 transition-all duration-1000"
                      style={{
                        width: lang === 'Arabic' ? '100%' : lang === 'English' ? '65%' : '30%',
                        transitionDelay: '300ms',
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default memo(Honors)
