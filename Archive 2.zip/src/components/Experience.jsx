import { memo } from 'react'
import { useInView } from '../hooks/useInView'
import data from '../data/portfolio.json'

function Experience() {
  const { experience } = data
  const [ref, inView] = useInView()

  return (
    <section
      id="experience"
      ref={ref}
      className="relative min-h-screen flex items-center px-4 py-16 bg-slate-50"
    >
      <div className="w-full max-w-4xl mx-auto">
        <h2 className={`text-3xl md:text-4xl font-bold text-slate-900 text-center mb-4 transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}>
          Professional Experience
        </h2>
        <p className={`text-slate-500 text-center mb-12 transition-all duration-700 delay-100 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}>
          Where I have worked and what I achieved
        </p>

        <div className="relative">
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px bg-slate-200 md:-translate-x-px" />

          <div className="space-y-10">
            {experience.map((job, i) => {
              const isLeft = i % 2 === 0
              return (
                <div
                  key={i}
                  className={`relative flex flex-col md:flex-row items-start gap-6 transition-all duration-700 ${
                    inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                  }`}
                  style={{ transitionDelay: `${i * 150}ms` }}
                >
                  <div className={`hidden md:flex w-1/2 ${isLeft ? 'justify-end pr-8' : 'justify-start pl-8 order-1'}`}>
                    {isLeft ? (
                      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                        <div className="flex flex-col">
                          <h3 className="text-lg font-semibold text-slate-900">{job.role}</h3>
                          <p className="text-blue-600 font-medium text-sm">{job.company}</p>
                          <span className="text-xs text-slate-400 mt-1">{job.period}</span>
                        </div>
                      </div>
                    ) : (
                      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                        <ul className="space-y-2">
                          {job.highlights.map((h, j) => (
                            <li key={j} className="flex gap-2 text-sm text-slate-600 leading-relaxed">
                              <span className="text-blue-500 mt-1 shrink-0">•</span>
                              <span>{h}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>

                  <div className="absolute left-4 md:left-1/2 w-3 h-3 rounded-full bg-blue-600 border-2 border-white md:-translate-x-1.5 mt-2 z-10" />

                  <div className="md:hidden w-full pl-8">
                    <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
                      <h3 className="text-base font-semibold text-slate-900">{job.role}</h3>
                      <p className="text-blue-600 font-medium text-sm">{job.company}</p>
                      <span className="text-xs text-slate-400 block mt-1 mb-3">{job.period}</span>
                      <ul className="space-y-1.5">
                        {job.highlights.map((h, j) => (
                          <li key={j} className="flex gap-2 text-sm text-slate-600">
                            <span className="text-blue-500 mt-1 shrink-0">•</span>
                            <span>{h}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className={`hidden md:flex w-1/2 ${isLeft ? 'justify-start pl-8 order-1' : 'justify-end pr-8'}`}>
                    {isLeft ? (
                      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                        <ul className="space-y-2">
                          {job.highlights.map((h, j) => (
                            <li key={j} className="flex gap-2 text-sm text-slate-600 leading-relaxed">
                              <span className="text-blue-500 mt-1 shrink-0">•</span>
                              <span>{h}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ) : (
                      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                        <div className="flex flex-col">
                          <h3 className="text-lg font-semibold text-slate-900">{job.role}</h3>
                          <p className="text-blue-600 font-medium text-sm">{job.company}</p>
                          <span className="text-xs text-slate-400 mt-1">{job.period}</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}

export default memo(Experience)
