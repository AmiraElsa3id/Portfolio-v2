import { memo } from 'react'
import { useInView } from '../hooks/useInView'
import data from '../data/portfolio.json'

function ProjectImage({ src, alt }) {
  const base = src.replace(/\.\w+$/, '')
  return (
    <picture>
      <source srcSet={`${base}.webp`} type="image/webp" />
      <img
        src={src}
        alt={alt}
        loading="lazy"
        decoding="async"
        className="w-full h-48 object-cover border-b border-slate-200 group-hover:scale-105 transition-transform duration-500"
      />
    </picture>
  )
}

function Projects() {
  const { projects } = data
  const [ref, inView] = useInView()

  return (
    <section
      id="projects"
      ref={ref}
      className="relative min-h-screen flex items-center px-4 py-16 bg-white"
    >
      <div className="w-full max-w-5xl mx-auto">
        <h2 className={`text-3xl md:text-4xl font-bold text-slate-900 text-center mb-4 transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}>
          Projects
        </h2>
        <p className={`text-slate-500 text-center mb-12 transition-all duration-700 delay-100 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}>
          Things I have built
        </p>

        <div className={`grid grid-cols-1 md:grid-cols-2 gap-6 animate-stagger ${inView ? 'visible' : ''}`}>
          {projects.map((proj, i) => (
            <div
              key={i}
              className="group bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
            >
              {proj.image ? (
                <div className="overflow-hidden">
                  <ProjectImage src={proj.image} alt={proj.name} />
                </div>
              ) : (
                <div className="relative w-full h-36 bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center border-b border-slate-200 overflow-hidden">
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(59,130,246,0.05),transparent_70%)]" />
                  <span className="text-slate-400 text-sm font-medium relative">Screenshot coming soon</span>
                </div>
              )}
              <div className="p-5">
                <h3 className="text-lg font-semibold text-slate-900 mb-1 group-hover:text-blue-600 transition-colors">{proj.name}</h3>
                <p className="text-xs text-blue-600 font-medium mb-3">{proj.tech}</p>
                <p className="text-sm text-slate-600 leading-relaxed mb-4 line-clamp-3">{proj.description}</p>
                <div className="flex gap-3">
                  {proj.links.code && (
                    <a href={proj.links.code} target="_blank" rel="noopener noreferrer"
                      className="group/btn inline-flex items-center gap-1.5 text-sm text-slate-600 hover:text-blue-600 font-medium transition">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/></svg>
                      Code
                      <span className="opacity-0 group-hover/btn:opacity-100 transition group-hover/btn:translate-x-0.5">→</span>
                    </a>
                  )}
                  {proj.links.demo && (
                    <a href={proj.links.demo} target="_blank" rel="noopener noreferrer"
                      className="group/btn inline-flex items-center gap-1.5 text-sm text-slate-600 hover:text-blue-600 font-medium transition">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
                      Demo
                      <span className="opacity-0 group-hover/btn:opacity-100 transition group-hover/btn:translate-x-0.5">→</span>
                    </a>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default memo(Projects)
