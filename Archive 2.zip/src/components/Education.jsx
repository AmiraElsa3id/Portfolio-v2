import { memo } from 'react'
import { useInView } from '../hooks/useInView'
import data from '../data/portfolio.json'

function Education() {
  const { education } = data
  const [ref, inView] = useInView()

  return (
    <section
      id="education"
      ref={ref}
      className="relative min-h-screen flex items-center px-4 py-16 bg-slate-900"
    >
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-blue-900/10 via-transparent to-transparent" />
      <div className="relative w-full max-w-4xl mx-auto">
        <h2 className={`text-3xl md:text-4xl font-bold text-white text-center mb-4 transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}>
          Education
        </h2>
        <p className={`text-slate-400 text-center mb-12 transition-all duration-700 delay-100 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}>
          Academic background and certifications
        </p>

        <div className="space-y-5">
          {education.map((edu, i) => (
            <div
              key={i}
              className={`bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 hover:bg-white/10 hover:border-blue-500/30 transition-all duration-300 ${
                inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${i * 120}ms`, transitionProperty: 'opacity, transform' }}
            >
              <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between mb-1">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-blue-500 shrink-0" />
                  <div>
                    <h3 className="text-base font-semibold text-white">{edu.degree}</h3>
                    <p className="text-sm text-blue-300">{edu.school}</p>
                  </div>
                </div>
                <span className="text-xs text-slate-500 mt-1 sm:mt-0 sm:ml-4 shrink-0">{edu.period}</span>
              </div>
              {edu.details.length > 0 && (
                <ul className="mt-3 space-y-1 ml-5">
                  {edu.details.map((d, j) => (
                    <li key={j} className="flex gap-2 text-sm text-slate-400">
                      <span className="text-blue-500 mt-1 shrink-0">•</span>
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default memo(Education)
