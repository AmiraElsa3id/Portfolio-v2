import { memo, useState } from 'react'
import { useInView } from '../hooks/useInView'

const FORM_ENDPOINT = 'https://formspree.io/f/mgobknjq'

function Contact() {
  const [state, setState] = useState({ status: '', message: '' })
  const [ref, inView] = useInView()

  const handleSubmit = async (e) => {
    e.preventDefault()
    const form = e.target
    const data = new FormData(form)

    setState({ status: 'sending', message: '' })

    try {
      const res = await fetch(FORM_ENDPOINT, {
        method: 'POST',
        body: data,
        headers: { Accept: 'application/json' },
      })
      if (res.ok) {
        setState({ status: 'success', message: 'Message sent! I will get back to you soon.' })
        form.reset()
      } else {
        const json = await res.json()
        setState({ status: 'error', message: json.error || 'Something went wrong.' })
      }
    } catch {
      setState({ status: 'error', message: 'Network error. Please try again.' })
    }
  }

  return (
    <section
      id="contact"
      ref={ref}
      className="relative min-h-screen flex items-center px-4 py-16 bg-slate-900"
    >
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-900/10 via-transparent to-transparent" />
      <div className="relative w-full max-w-2xl mx-auto">
        <h2 className={`text-3xl md:text-4xl font-bold text-white text-center mb-4 transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}>
          Get in Touch
        </h2>
        <p className={`text-slate-400 text-center mb-12 transition-all duration-700 delay-100 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}>
          Have a question or want to work together?
        </p>

        <form
          onSubmit={handleSubmit}
          className={`space-y-5 transition-all duration-700 delay-200 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <input
              type="text"
              name="name"
              required
              placeholder="Your Name"
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-slate-500 outline-none focus:border-blue-500/50 focus:bg-white/10 transition text-sm"
            />
            <input
              type="email"
              name="email"
              required
              placeholder="Your Email"
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-slate-500 outline-none focus:border-blue-500/50 focus:bg-white/10 transition text-sm"
            />
          </div>
          <input
            type="text"
            name="subject"
            placeholder="Subject"
            className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-slate-500 outline-none focus:border-blue-500/50 focus:bg-white/10 transition text-sm"
          />
          <textarea
            name="message"
            rows="5"
            required
            placeholder="Your Message"
            className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-slate-500 outline-none focus:border-blue-500/50 focus:bg-white/10 transition text-sm resize-none"
          />

          <button
            type="submit"
            disabled={state.status === 'sending'}
            className="w-full py-3 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl text-white font-medium transition text-sm"
          >
            {state.status === 'sending' ? 'Sending...' : 'Send Message'}
          </button>

          {state.message && (
            <p className={`text-sm text-center ${state.status === 'success' ? 'text-green-400' : 'text-red-400'}`}>
              {state.message}
            </p>
          )}
        </form>
      </div>
    </section>
  )
}

export default memo(Contact)
